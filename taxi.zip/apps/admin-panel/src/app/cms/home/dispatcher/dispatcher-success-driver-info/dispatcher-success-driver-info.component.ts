import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dispatcher-success-driver-info',
  templateUrl: './dispatcher-success-driver-info.component.html',
  styles: [
  ]
})
export class DispatcherSuccessDriverInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
